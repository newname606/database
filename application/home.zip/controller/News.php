<?php
/**
 * Created by PhpStorm.
 * User: gaming
 * Date: 2020/6/22
 * Time: 12:05
 */

namespace app\home\controller;


use think\Controller;

class News extends Controller
{
    function _initialize()
    {
        $this->assign('nav','3');
    }

    public function index(){
        return $this->fetch();
    }

}