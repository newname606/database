<?php
/**
 * Created by PhpStorm.
 * User: gaming
 * Date: 2020/6/23
 * Time: 10:49
 */
define('BIND_MODULE', 'competition');

define('APP_PATH', __DIR__ . '/../application/');
// 加载框架引导文件
require __DIR__ . '/../thinkphp/start.php';

