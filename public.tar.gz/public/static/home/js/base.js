
// 弹窗
function tip(str, fun) {
	fun = (typeof fun) == "function" ? fun : "";
	if(str && str != ""){

	}else{
		str = "提示内容为空";
	}
	var tipbox = '<div class="tipbox">'
					+'<div class="mask"></div>'
					+'<div class="modal">'
						+'<div class="modal__bd">'+str+'</div>'
						+'<div class="modal__ft">'
							+'<div class="modal__btn modal__btn_primary">确定</div>'
						+'</div>'
					+'</div>'
				+'</div>';
	
	$("body").append(tipbox);
	$("body").on("click",".modal__btn",function () {
		$(".tipbox .modal__bd").html("");
		$(".tipbox").remove();
		if(fun) {
			fun();
		}
	})
}
				
// 验证手机号
function checkPhone(tel){ 
	if(!(/^1[3456789]\d{9}$/.test(tel))){  
		return false; 
	}  else {
		return true; 
	}
}